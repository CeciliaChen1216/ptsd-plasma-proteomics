# Raw audit records and subsequent interpretation

The CSV/TXT/log files in this folder are the original author-supplied full-file audit outputs, retained byte-for-byte apart from canonical filename suffixes. Their recorded execution environment and historical cautions have not been overwritten.

The subsequent, separate case/control-deficit diagnostic is implemented in `scripts/PTSD_NEFF_count_patterns.R`. Its R-generated S24c components are in `results_snapshot/current_manuscript_components/`. It supports a cohort-additive structure for 67 matched count patterns (2,270,303 variants; 19 named cohorts), but does not recover all absolute cohort weights or establish the global unique-participant count. The current README and manuscript use this qualified interpretation, rather than treating the earlier raw log as a new final statement.
