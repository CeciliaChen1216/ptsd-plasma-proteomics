Review-only bundle; full aligned data, genotypes, LD and fit objects remain in the original result directory.
No-SuSiE-pair statuses distinguish missing credible sets from fitting errors; ABF H0-H4 are retained.
Maximum-pair PP.H4 is descriptive, not a mean or automatic effector assignment.
