# Reviewed expanded instrument analysis

Original successful run: sem_instrument_expansion_20261019_092632_712c39553a8d.
Both specifications contain 1,162 protein tests and 1,152 unique SNPs.
Primary: 51 MR-FDR associations, 87 nominal Q_SNP tests, zero Q_SNP-FDR associations.
Source-NEFF sensitivity: 50 MR-FDR associations, 85 nominal Q_SNP tests, zero Q_SNP-FDR associations.
Nine of ten PTSD candidates are testable and eight are MR-FDR significant in both specifications.
SIRPA is unavailable because rs6136377 is absent from the raw MDD GWAS. CD101 is testable but not MR-FDR significant.

Original output files are preserved byte-for-byte. The README and comparison_primary_NEFF.csv are release additions.
Files named previous_* document the historical 391-protein/387-SNP baseline; they are not the default report results.
The top-level results_snapshot/factor_MR.csv is an exact copy of primary/factor_MR_expanded.csv.
Raw logs record original local paths, warnings and cache locations; they have not been retrospectively edited.
Only targeted summary statistics, derived estimates and aggregated frequencies are included, not full GWAS or LD genotypes.
