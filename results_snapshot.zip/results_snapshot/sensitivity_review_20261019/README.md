# Sensitivity annotation review, 19 October 2026

These small inputs preserve the displayed association values in Additional file 3, Tables S3a, S7b, S8 and S14. They support plot and table regeneration without another GWAS/MR/SMR run.

- `eqtl_smr_direction.csv`: 20 tissue/gene rows, original SMR/HEIDI/FDR values and the plasma Wald beta comparator. Nine qualify statistically; five qualified rows have opposite signs across four genes.
- `reverse_mr_review.csv`: ten paired IVW/weighted-median results. Six IVW P values are <0.05; CD40 also has a concordant weighted-median P<0.05. P values are unadjusted.
- `evidence_matrix.csv`: 80 domain states and text labels. Other domain definitions retain the previously reviewed S2 states, including supportive but prior-sensitive FES colocalization and inconclusive FURIN colocalization. Opposite/mixed qualified transcript results and reverse-IVW signals are cautionary. Tested null multi-IVW results are distinct from unavailable tests.

Association qualification, direction concordance and testability are separate. No mechanism, absence of bias or composite evidence score is inferred from these annotations. Exact numbers retain the source table's displayed precision.
