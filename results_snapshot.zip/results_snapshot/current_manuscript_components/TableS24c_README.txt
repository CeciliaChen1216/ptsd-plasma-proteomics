Table S24c, Additional file 3: regenerated from frozen full-file audit outputs.
Summary = workbook section A; header cohorts = B; count-pattern matches = C.
The original R audit creates the small input files from the verified Figshare v3 GWAS.
Search: one to three distinct header cohorts; exact case/control deficits relative to the most frequent pattern.
All count matches are retained. NEFF is checked afterwards, not used to select matches.
Cohort effective N = 4*cases*controls/(cases+controls), rounded upward separately within cohort.
Count-pattern matching supports a cohort-additive structure but does not establish per-variant cohort membership.
Absolute cohort weights and unique global participant counts remain unresolved.
This export does not rerun MR/LDSC/SEM/COJO or rewrite the formatted Word/XLSX files.
