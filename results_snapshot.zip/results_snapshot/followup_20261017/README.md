# SEM and conditional SNP analysis outputs

- `sem/` contains the source-NEFF SEM outputs. Status records describe the SEM run and its associated conditional-analysis attempt; the completed conditional SNP outputs are in `cojo/`.
- `cojo/` contains the completed PTSD-only COJO results and execution records.
- `sem/stage12_factorMR_results.csv` contains 391 protein results used as baseline controls.
- `sem/comparison_with_reviewed.csv` contains the corresponding 391-row comparison.
- `../current_manuscript_components/` contains the S22, S24b and S26b numerical components.

The default 1,162-protein SEM report inputs are in `../sem_expansion_20261019/`. The trait-model coefficients and conditional SNP results in this directory remain part of the study evidence. Baseline outputs and unsuccessful-attempt logs are retained for traceability and are not substituted for completed analyses. Genotype BED/BIM/FAM and complete source GWAS files are not redistributed.
